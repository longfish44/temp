from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.contrib.auth import login, logout, authenticate
from .forms import CompareImageForm
from .models import CompareImageModels
from .forms import testModelForm
from .models import testModels
from django.utils import timezone
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request,'compareimages/home.html')

def analysis(request):
    if request.method == 'GET':
        return render(request, 'compareimages/analysis.html', {'form':CompareImageForm()})
    else:
        try:
            form = CompareImageForm(request.POST)
            newanalysis = form.save(commit=False)
            newanalysis.save()
            return redirect('analysis')
        except ValueError:
            return render(request, 'compareimages/analysis.html', {'form':CompareImageForm(), 'error':'analysis Bad data passed in. Try again.'})

def analysisAzure(request):
    if request.method == 'GET':
        return render(request, 'compareimages/analysis.html', {'form':CompareImageForm()})
    else:
        try:
            form = CompareImageForm(request.POST)
            newtodo = form.save(commit=False)
            newtodo.user = request.user
            newtodo.save()
            return redirect('currenttodos')
        except ValueError:
            return render(request, 'compareimages/createtodo.html', {'form':CompareImageForm(), 'error':'Bad data passed in. Try again.'})

def testModel(request):
    if request.method == 'GET':
        return render(request, 'compareimages/testModel.html', {'form':testModelForm()})
    else:
        try:
            form = testModelForm(request.POST)
            newtest = form.save(commit=False)
            newtest.save()
            return redirect('currenttest')
        except ValueError:
            return render(request, 'compareimages/testModel.html', {'form':testModelForm(), 'error':'testModel Bad data passed in. Try again.'})

def currenttest(request):
    tests = testModels.objects.all
    return render(request, 'compareimages/currenttest.html', {'tests':tests})


def signupuser(request):
    if request.method == 'GET':
        return render(request, 'compareimages/signupuser.html', {'form':UserCreationForm()})
    else:
        if request.POST['password1'] == request.POST['password2']:
            try:
                user = User.objects.create_user(request.POST['username'], password=request.POST['password1'])
                user.save()
                login(request, user)
                return redirect('currenttodos')
            except IntegrityError:
                return render(request, 'compareimages/signupuser.html', {'form':UserCreationForm(), 'error':'That username has already been taken. Please choose a new username'})
        else:
            return render(request, 'compareimages/signupuser.html', {'form':UserCreationForm(), 'error':'Passwords did not match'})

def loginuser(request):
    if request.method == 'GET':
        return render(request, 'compareimages/loginuser.html', {'form':AuthenticationForm()})
    else:
        user = authenticate(request, username=request.POST['username'], password=request.POST['password'])
        if user is None:
            return render(request, 'compareimages/loginuser.html', {'form':AuthenticationForm(), 'error':'Username and password did not match'})
        else:
            login(request, user)
            return redirect('currenttodos')

@login_required
def logoutuser(request):
    if request.method == 'POST':
        logout(request)
        return redirect('home')

@login_required
def createtodo(request):
    if request.method == 'GET':
        return render(request, 'compareimages/createtodo.html', {'form':CompareImageForm()})
    else:
        try:
            form = CompareImageForm(request.POST)
            newtodo = form.save(commit=False)
            newtodo.user = request.user
            newtodo.save()
            return redirect('currenttodos')
        except ValueError:
            return render(request, 'compareimages/createtodo.html', {'form':CompareImageForm(), 'error':'Bad data passed in. Try again.'})

def currenttodos(request):
    todos = CompareImageModels.objects.filter(user=request.user, image_title1__isnull=True)
    return render(request, 'compareimages/currenttodos.html', {'todos':todos})

@login_required
def completedtodos(request):
    todos = CompareImageModels.objects.filter(user=request.user, image_title1__isnull=False).order_by('-image_title1')
    return render(request, 'compareimages/completedtodos.html', {'todos':todos})

@login_required
def viewtodo(request, todo_pk):
    todo = get_object_or_404(CompareImageModels, pk=todo_pk, user=request.user)
    if request.method == 'GET':
        form = CompareImageForm(instance=todo)
        return render(request, 'compareimages/viewtodo.html', {'todo':todo, 'form':form})
    else:
        try:
            form = CompareImageForm(request.POST, instance=todo)
            form.save()
            return redirect('currenttodos')
        except ValueError:
            return render(request, 'compareimages/viewtodo.html', {'todo':todo, 'form':form, 'error':'Bad info'})

@login_required
def completetodo(request, todo_pk):
    todo = get_object_or_404(CompareImageModels, pk=todo_pk, user=request.user)
    if request.method == 'POST':
        todo.datecompleted = timezone.now()
        todo.save()
        return redirect('currenttodos')

@login_required
def deletetodo(request, todo_pk):
    todo = get_object_or_404(CompareImageModels, pk=todo_pk, user=request.user)
    if request.method == 'POST':
        todo.delete()
        return redirect('currenttodos')
