from django.contrib import admin
from .models import CompareImageModels
from .models import testModels

admin.site.register(CompareImageModels)

admin.site.register(testModels)
