from django.forms import ModelForm
from .models import CompareImageModels
from .models import testModels

class CompareImageForm(ModelForm):
    class Meta:
        model = CompareImageModels
        fields = ['image_title1']

class testModelForm(ModelForm):
    class Meta:
        model = testModels
        fields = ['test1']
