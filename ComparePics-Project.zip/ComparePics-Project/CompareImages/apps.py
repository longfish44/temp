from django.apps import AppConfig


class CompareimagesConfig(AppConfig):
    name = 'CompareImages'
